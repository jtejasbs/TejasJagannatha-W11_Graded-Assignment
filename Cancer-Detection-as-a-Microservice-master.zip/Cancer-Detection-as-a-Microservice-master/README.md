> **Objective**: Trained a Voting Classifier to predict cancer type with the Wisconsin Breast Cancer Dataset. Hosted the model as a Flask-based microservice running within a Docker container.
